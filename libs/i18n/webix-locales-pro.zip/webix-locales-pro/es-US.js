/*Spanish (United States) locale*/
webix.i18n.locales["es-US"] = {
	groupDelimiter:",",
	groupSize:3,
	decimalDelimiter:".",
	decimalSize:2,
	am:["am","AM"],
	pm:["pm","PM"],
	price:"${obj}",
	priceSettings:{
		groupDelimiter:",",
		groupSize:3,
		decimalDelimiter:".",
		decimalSize:2
	},
	calendar:{
		monthFull:["enero","febrero","marzo","abril","mayo","junio","julio","agosto","septiembre","octubre","noviembre","diciembre"],
		monthShort:["ene","feb","mar","abr","may","jun","jul","ago","sep","oct","nov","dic"],
		dayFull:["domingo","lunes","martes","miércoles","jueves","viernes","sábado"],
		dayShort:["dom","lun","mar","mié","jue","vie","sáb"]
	}
};
