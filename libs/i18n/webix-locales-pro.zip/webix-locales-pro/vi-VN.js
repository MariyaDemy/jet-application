/*Vietnamese (Vietnam) locale*/
webix.i18n.locales["vi-VN"] = {
	groupDelimiter:".",
	groupSize:3,
	decimalDelimiter:",",
	decimalSize:2,
	dateFormat:"%d/%n/%Y",
	longDateFormat:"%d %F %Y",
	fullDateFormat:"%d %F %Y %g:%i %a",
	am:["SA","SA"],
	pm:["CH","CH"],
	price:"{obj} ₫",
	priceSettings:{
		groupDelimiter:".",
		groupSize:3,
		decimalDelimiter:",",
		decimalSize:2
	},
	calendar:{
		monthFull:["Tháng Giêng","Tháng Hai","Tháng Ba","Tháng Tư","Tháng Năm","Tháng Sáu","Tháng Bảy","Tháng Tám","Tháng Chín","Tháng Mười","Tháng Mười Một","Tháng Mười Hai"],
		monthShort:["Thg1","Thg2","Thg3","Thg4","Thg5","Thg6","Thg7","Thg8","Thg9","Thg10","Thg11","Thg12"],
		dayFull:["Chủ Nhật","Thứ Hai","Thứ Ba","Thứ Tư","Thứ Năm","Thứ Sáu","Thứ Bảy"],
		dayShort:["CN","Hai","Ba","Tư","Năm","Sáu","Bảy"]
	}
};
