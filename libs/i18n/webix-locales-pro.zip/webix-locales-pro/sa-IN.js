/*Sanskrit (India) locale*/
webix.i18n.locales["sa-IN"] = {
	groupDelimiter:",",
	groupSize:3,
	decimalDelimiter:".",
	decimalSize:2,
	dateFormat:"%d-%n-%Y",
	timeFormat:"%H:%i",
	longDateFormat:"%d %F %Y %l",
	fullDateFormat:"%d %F %Y %l %H:%i",
	am:["पूर्वाह्न","पूर्वाह्न"],
	pm:["अपराह्न","अपराह्न"],
	price:"रु {obj}",
	priceSettings:{
		groupDelimiter:",",
		groupSize:3,
		decimalDelimiter:".",
		decimalSize:2
	},
	calendar:{
		monthFull:["जनवरी","फरवरी","मार्च","अप्रैल","मई","जून","जुलाई","अगस्त","सितम्बर","अक्तूबर","नवम्बर","दिसम्बर"],
		monthShort:["जनवरी","फरवरी","मार्च","अप्रैल","मई","जून","जुलाई","अगस्त","सितम्बर","अक्तूबर","नवम्बर","दिसम्बर"],
		dayFull:["रविवासरः","सोमवासरः","मङ्गलवासरः","बुधवासरः","गुरुवासरः","शुक्रवासरः","शनिवासरः"],
		dayShort:["रविवासरः","सोमवासरः","मङ्गलवासरः","बुधवासरः","गुरुवासरः","शुक्रवासरः","शनिवासरः"]
	}
};
