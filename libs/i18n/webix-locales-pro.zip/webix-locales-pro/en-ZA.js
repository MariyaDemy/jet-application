/*English (South Africa) locale*/
webix.i18n.locales["en-ZA"] = {
	groupDelimiter:" ",
	groupSize:3,
	decimalDelimiter:".",
	decimalSize:2,
	dateFormat:"%Y/%n/%d",
	timeFormat:"%h:%i %a",
	longDateFormat:"%d %F %Y",
	fullDateFormat:"%d %F %Y %h:%i %a",
	am:["am","AM"],
	pm:["pm","PM"],
	price:"R {obj}",
	priceSettings:{
		groupDelimiter:" ",
		groupSize:3,
		decimalDelimiter:",",
		decimalSize:2
	}
};
