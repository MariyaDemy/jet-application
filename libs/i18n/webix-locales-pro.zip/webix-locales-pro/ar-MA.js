/*Arabic (Morocco) locale*/
webix.i18n.locales["ar-MA"] = {
	groupDelimiter:",",
	groupSize:3,
	decimalDelimiter:".",
	decimalSize:2,
	dateFormat:"%d-%n-%Y",
	timeFormat:"%G:%i",
	longDateFormat:"%d %F, %Y",
	fullDateFormat:"%d %F, %Y %G:%i",
	am:["ص","ص"],
	pm:["م","م"],
	price:"د.م.‏ {obj}",
	priceSettings:{
		groupDelimiter:",",
		groupSize:3,
		decimalDelimiter:".",
		decimalSize:2
	},
	calendar:{
		monthFull:["يناير","فبراير","مارس","أبريل","ماي","يونيو","يوليوز","غشت","شتنبر","أكتوبر","نونبر","دجنبر"],
		monthShort:["يناير","فبراير","مارس","أبريل","ماي","يونيو","يوليوز","غشت","شتنبر","أكتوبر","نونبر","دجنبر"],
		dayFull:["الأحد","الإثنين","الثلاثاء","الأربعاء","الخميس","الجمعة","السبت"],
		dayShort:["الأحد","الإثنين","الثلاثاء","الأربعاء","الخميس","الجمعة","السبت"]
	}
};
